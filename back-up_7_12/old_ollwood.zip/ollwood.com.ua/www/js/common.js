/*
 * jQuery Easing v1.3 - http://gsgd.co.uk/sandbox/jquery/easing/
 *
 * Uses the built in easing capabilities added In jQuery 1.1
 * to offer multiple easing options
 *
 * TERMS OF USE - jQuery Easing
 *
 * Open source under the BSD License.
 *
 * Copyright © 2008 George McGinley Smith
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this list of
 * conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list
 * of conditions and the following disclaimer in the documentation and/or other materials
 * provided with the distribution.
 *
 * Neither the name of the author nor the names of contributors may be used to endorse
 * or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

// t: current time, b: begInnIng value, c: change In value, d: duration
jQuery.easing['jswing'] = jQuery.easing['swing'];

jQuery.extend( jQuery.easing,
	{
		def: 'easeOutQuad',
		swing: function (x, t, b, c, d) {
			//alert(jQuery.easing.default);
			return jQuery.easing[jQuery.easing.def](x, t, b, c, d);
		},
		easeInQuad: function (x, t, b, c, d) {
			return c*(t/=d)*t + b;
		},
		easeOutQuad: function (x, t, b, c, d) {
			return -c *(t/=d)*(t-2) + b;
		},
		easeInOutQuad: function (x, t, b, c, d) {
			if ((t/=d/2) < 1) return c/2*t*t + b;
			return -c/2 * ((--t)*(t-2) - 1) + b;
		},
		easeInCubic: function (x, t, b, c, d) {
			return c*(t/=d)*t*t + b;
		},
		easeOutCubic: function (x, t, b, c, d) {
			return c*((t=t/d-1)*t*t + 1) + b;
		},
		easeInOutCubic: function (x, t, b, c, d) {
			if ((t/=d/2) < 1) return c/2*t*t*t + b;
			return c/2*((t-=2)*t*t + 2) + b;
		},
		easeInQuart: function (x, t, b, c, d) {
			return c*(t/=d)*t*t*t + b;
		},
		easeOutQuart: function (x, t, b, c, d) {
			return -c * ((t=t/d-1)*t*t*t - 1) + b;
		},
		easeInOutQuart: function (x, t, b, c, d) {
			if ((t/=d/2) < 1) return c/2*t*t*t*t + b;
			return -c/2 * ((t-=2)*t*t*t - 2) + b;
		},
		easeInQuint: function (x, t, b, c, d) {
			return c*(t/=d)*t*t*t*t + b;
		},
		easeOutQuint: function (x, t, b, c, d) {
			return c*((t=t/d-1)*t*t*t*t + 1) + b;
		},
		easeInOutQuint: function (x, t, b, c, d) {
			if ((t/=d/2) < 1) return c/2*t*t*t*t*t + b;
			return c/2*((t-=2)*t*t*t*t + 2) + b;
		},
		easeInSine: function (x, t, b, c, d) {
			return -c * Math.cos(t/d * (Math.PI/2)) + c + b;
		},
		easeOutSine: function (x, t, b, c, d) {
			return c * Math.sin(t/d * (Math.PI/2)) + b;
		},
		easeInOutSine: function (x, t, b, c, d) {
			return -c/2 * (Math.cos(Math.PI*t/d) - 1) + b;
		},
		easeInExpo: function (x, t, b, c, d) {
			return (t==0) ? b : c * Math.pow(2, 10 * (t/d - 1)) + b;
		},
		easeOutExpo: function (x, t, b, c, d) {
			return (t==d) ? b+c : c * (-Math.pow(2, -10 * t/d) + 1) + b;
		},
		easeInOutExpo: function (x, t, b, c, d) {
			if (t==0) return b;
			if (t==d) return b+c;
			if ((t/=d/2) < 1) return c/2 * Math.pow(2, 10 * (t - 1)) + b;
			return c/2 * (-Math.pow(2, -10 * --t) + 2) + b;
		},
		easeInCirc: function (x, t, b, c, d) {
			return -c * (Math.sqrt(1 - (t/=d)*t) - 1) + b;
		},
		easeOutCirc: function (x, t, b, c, d) {
			return c * Math.sqrt(1 - (t=t/d-1)*t) + b;
		},
		easeInOutCirc: function (x, t, b, c, d) {
			if ((t/=d/2) < 1) return -c/2 * (Math.sqrt(1 - t*t) - 1) + b;
			return c/2 * (Math.sqrt(1 - (t-=2)*t) + 1) + b;
		},
		easeInElastic: function (x, t, b, c, d) {
			var s=1.70158;var p=0;var a=c;
			if (t==0) return b;  if ((t/=d)==1) return b+c;  if (!p) p=d*.3;
			if (a < Math.abs(c)) { a=c; var s=p/4; }
			else var s = p/(2*Math.PI) * Math.asin (c/a);
			return -(a*Math.pow(2,10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
		},
		easeOutElastic: function (x, t, b, c, d) {
			var s=1.70158;var p=0;var a=c;
			if (t==0) return b;  if ((t/=d)==1) return b+c;  if (!p) p=d*.3;
			if (a < Math.abs(c)) { a=c; var s=p/4; }
			else var s = p/(2*Math.PI) * Math.asin (c/a);
			return a*Math.pow(2,-10*t) * Math.sin( (t*d-s)*(2*Math.PI)/p ) + c + b;
		},
		easeInOutElastic: function (x, t, b, c, d) {
			var s=1.70158;var p=0;var a=c;
			if (t==0) return b;  if ((t/=d/2)==2) return b+c;  if (!p) p=d*(.3*1.5);
			if (a < Math.abs(c)) { a=c; var s=p/4; }
			else var s = p/(2*Math.PI) * Math.asin (c/a);
			if (t < 1) return -.5*(a*Math.pow(2,10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )) + b;
			return a*Math.pow(2,-10*(t-=1)) * Math.sin( (t*d-s)*(2*Math.PI)/p )*.5 + c + b;
		},
		easeInBack: function (x, t, b, c, d, s) {
			if (s == undefined) s = 1.70158;
			return c*(t/=d)*t*((s+1)*t - s) + b;
		},
		easeOutBack: function (x, t, b, c, d, s) {
			if (s == undefined) s = 1.70158;
			return c*((t=t/d-1)*t*((s+1)*t + s) + 1) + b;
		},
		easeInOutBack: function (x, t, b, c, d, s) {
			if (s == undefined) s = 1.70158;
			if ((t/=d/2) < 1) return c/2*(t*t*(((s*=(1.525))+1)*t - s)) + b;
			return c/2*((t-=2)*t*(((s*=(1.525))+1)*t + s) + 2) + b;
		},
		easeInBounce: function (x, t, b, c, d) {
			return c - jQuery.easing.easeOutBounce (x, d-t, 0, c, d) + b;
		},
		easeOutBounce: function (x, t, b, c, d) {
			if ((t/=d) < (1/2.75)) {
				return c*(7.5625*t*t) + b;
			} else if (t < (2/2.75)) {
				return c*(7.5625*(t-=(1.5/2.75))*t + .75) + b;
			} else if (t < (2.5/2.75)) {
				return c*(7.5625*(t-=(2.25/2.75))*t + .9375) + b;
			} else {
				return c*(7.5625*(t-=(2.625/2.75))*t + .984375) + b;
			}
		},
		easeInOutBounce: function (x, t, b, c, d) {
			if (t < d/2) return jQuery.easing.easeInBounce (x, t*2, 0, c, d) * .5 + b;
			return jQuery.easing.easeOutBounce (x, t*2-d, 0, c, d) * .5 + c*.5 + b;
		}
	});

/*
 *
 * TERMS OF USE - EASING EQUATIONS
 *
 * Open source under the BSD License.
 *
 * Copyright © 2001 Robert Penner
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this list of
 * conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list
 * of conditions and the following disclaimer in the documentation and/or other materials
 * provided with the distribution.
 *
 * Neither the name of the author nor the names of contributors may be used to endorse
 * or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
	(function($) {
		$.fn.parallaxSlider = function(options) {
			var opts = $.extend({}, $.fn.parallaxSlider.defaults, options);
			return this.each(function() {
				var $pxs_container 	= $(this),
					o 				= $.meta ? $.extend({}, opts, $pxs_container.data()) : opts;

				//the main slider
				var $pxs_slider		= $('.pxs_slider',$pxs_container),
				//the elements in the slider
					$elems			= $pxs_slider.children(),
				//total number of elements
					total_elems		= $elems.length,
				//the navigation buttons
					$pxs_next		= $('.pxs_next',$pxs_container),
					$pxs_prev		= $('.pxs_prev',$pxs_container),
				//the bg images
					$pxs_bg1		= $('.pxs_bg1',$pxs_container),
					$pxs_bg2		= $('.pxs_bg2',$pxs_container),
					$pxs_bg3		= $('.pxs_bg3',$pxs_container),
				//current image
					current			= 0,
				//the thumbs container
					$pxs_thumbnails = $('.pxs_thumbnails',$pxs_container),
				//the thumbs
					$thumbs			= $pxs_thumbnails.children(),
				//the interval for the autoplay mode
					slideshow,
				//the loading image
					$pxs_loading	= $('.pxs_loading',$pxs_container),
					$pxs_slider_wrapper = $('.pxs_slider_wrapper',$pxs_container);

				//first preload all the images
				var loaded		= 0,
					$images		= $pxs_slider_wrapper.find('img');

				$images.each(function(){
					var $img	= $(this);
					$('<img/>').load(function(){
						++loaded;
						if(loaded	== total_elems*2){
							$pxs_loading.hide();
							$pxs_slider_wrapper.show();

							//one images width (assuming all images have the same sizes)
							var one_image_w		= $pxs_slider.find('img:first').width();

							/*
							 need to set width of the slider,
							 of each one of its elements, and of the
							 navigation buttons
							 */
							setWidths($pxs_slider,
								$elems,
								total_elems,
								$pxs_bg1,
								$pxs_bg2,
								$pxs_bg3,
								one_image_w,
								$pxs_next,
								$pxs_prev);

							/*
							 set the width of the thumbs
							 and spread them evenly
							 */
							$pxs_thumbnails.css({
								'width'			: one_image_w + 'px',
								'margin-left' 	: -one_image_w/2 + 'px'
							});
							var spaces	= one_image_w/(total_elems+1);
							$thumbs.each(function(i){
								var $this 	= $(this);
								var left	= spaces*(i+1) - $this.width()/2;
								$this.css('left',left+'px');

								if(o.thumbRotation){
									var angle 	= Math.floor(Math.random()*41)-20;
									$this.css({
										'-moz-transform'	: 'rotate('+ angle +'deg)',
										'-webkit-transform'	: 'rotate('+ angle +'deg)',
										'transform'			: 'rotate('+ angle +'deg)'
									});
								}
								//hovering the thumbs animates them up and down
								$this.bind('mouseenter',function(){
									$(this).stop().animate({top:'-10px'},100);
								}).bind('mouseleave',function(){
									$(this).stop().animate({top:'0px'},100);
								});
							});

							//make the first thumb be selected
							highlight($thumbs.eq(0));

							//slide when clicking the navigation buttons
							$pxs_next.bind('click',function(){
								++current;
								if(current >= total_elems)
									if(o.circular)
										current = 0;
									else{
										--current;
										return false;
									}
								highlight($thumbs.eq(current));
								slide(current,
									$pxs_slider,
									$pxs_bg3,
									$pxs_bg2,
									$pxs_bg1,
									o.speed,
									o.easing,
									o.easingBg);
							});
							$pxs_prev.bind('click',function(){
								--current;
								if(current < 0)
									if(o.circular)
										current = total_elems - 1;
									else{
										++current;
										return false;
									}
								highlight($thumbs.eq(current));
								slide(current,
									$pxs_slider,
									$pxs_bg3,
									$pxs_bg2,
									$pxs_bg1,
									o.speed,
									o.easing,
									o.easingBg);
							});

							/*
							 clicking a thumb will slide to the respective image
							 */
							$thumbs.bind('click',function(){
								var $thumb	= $(this);
								highlight($thumb);
								//if autoplay interrupt when user clicks
								if(o.auto)
									clearInterval(slideshow);
								current 	= $thumb.index();
								slide(current,
									$pxs_slider,
									$pxs_bg3,
									$pxs_bg2,
									$pxs_bg1,
									o.speed,
									o.easing,
									o.easingBg);
							});



							/*
							 activate the autoplay mode if
							 that option was specified
							 */
							if(o.auto != 0){
								o.circular	= true;
								slideshow	= setInterval(function(){
									$pxs_next.trigger('click');
								},o.auto);
							}

							/*
							 when resizing the window,
							 we need to recalculate the widths of the
							 slider elements, based on the new windows width.
							 we need to slide again to the current one,
							 since the left of the slider is no longer correct
							 */
							$(window).resize(function(){
								w_w	= $(window).width();
								setWidths($pxs_slider,$elems,total_elems,$pxs_bg1,$pxs_bg2,$pxs_bg3,one_image_w,$pxs_next,$pxs_prev);
								slide(current,
									$pxs_slider,
									$pxs_bg3,
									$pxs_bg2,
									$pxs_bg1,
									1,
									o.easing,
									o.easingBg);
							});

						}
					}).error(function(){
						alert('here')
					}).attr('src',$img.attr('src'));
				});



			});
		};

		//the current windows width
		var w_w				= $(window).width();

		var slide			= function(current,
										$pxs_slider,
										$pxs_bg3,
										$pxs_bg2,
										$pxs_bg1,
										speed,
										easing,
										easingBg){
			var slide_to	= parseInt(-w_w * current);
			$pxs_slider.stop().animate({
				left	: slide_to + 'px'
			},speed, easing);
			$pxs_bg3.stop().animate({
				left	: slide_to/2 + 'px'
			},speed, easingBg);
			$pxs_bg2.stop().animate({
				left	: slide_to/4 + 'px'
			},speed, easingBg);
			$pxs_bg1.stop().animate({
				left	: slide_to/8 + 'px'
			},speed, easingBg);
		}

		var highlight		= function($elem){
			$elem.siblings().removeClass('selected');
			$elem.addClass('selected');
		}

		var setWidths		= function($pxs_slider,
										$elems,
										total_elems,
										$pxs_bg1,
										$pxs_bg2,
										$pxs_bg3,
										one_image_w,
										$pxs_next,
										$pxs_prev){
			/*
			 the width of the slider is the windows width
			 times the total number of elements in the slider
			 */
			var pxs_slider_w	= w_w * total_elems;
			$pxs_slider.width(pxs_slider_w + 'px');
			//each element will have a width = windows width
			$elems.width(w_w + 'px');
			/*
			 we also set the width of each bg image div.
			 The value is the same calculated for the pxs_slider
			 */
			$pxs_bg1.width(pxs_slider_w + 'px');
			$pxs_bg2.width(pxs_slider_w + 'px');
			$pxs_bg3.width(pxs_slider_w + 'px');

			/*
			 both the right and left of the
			 navigation next and previous buttons will be:
			 windowWidth/2 - imgWidth/2 + some margin (not to touch the image borders)
			 */
			var position_nav	= w_w/2 - one_image_w/2 + 3;
			$pxs_next.css('right', position_nav + 'px');
			$pxs_prev.css('left', position_nav + 'px');
		}

		$.fn.parallaxSlider.defaults = {
			auto			: 0,	//how many seconds to periodically slide the content.
			//If set to 0 then autoplay is turned off.
			speed			: 1000,//speed of each slide animation
			easing			: 'jswing',//easing effect for the slide animation
			easingBg		: 'jswing',//easing effect for the background animation
			circular		: true,//circular slider
			thumbRotation	: true//the thumbs will be randomly rotated
		};
		//easeInOutExpo,easeInBack
	})(jQuery);

	$(function() {
		var $pxs_container	= $('#pxs_container, #pxs_container_first');
		$pxs_container.parallaxSlider();
	});
$(function() {

	//Chrome Smooth Scroll
	try {
		$.browserSelector();
		if($("html").hasClass("chrome")) {
			$.smoothScroll();
		}
	} catch(err) {

	};

	//PageScroll#id
	$("a.scroll").mPageScroll2id();

	//fancybox
	$("a.modal").fancybox();
	$("a.modall_pad").fancybox({
		padding: 0,
		margin: 0
	});

	//slick
	$('.slider-for').slick({
		slidesToShow: 1,
		slidesToScroll: 1,
		arrows: false,
		fade: true,
		asNavFor: '.slider-nav'
	});
	$('.slider-nav').slick({
		slidesToShow: 5,
		slidesToScroll: 1,
		asNavFor: '.slider-for',
		dots: false,
		focusOnSelect: true,
		arrows: false,
		responsive: [
		  {
		    breakpoint: 566,
		    settings: {
		      slidesToShow: 3,
		      centerMode: true
		    }
		  }
		]
	});

	//jScrollPane
	$('.scroll-pane').jScrollPane();

	//flickity
	$('#three .main-gallery ').flickity({
		cellAlign:'left',
		contain:true,
		wrapAround:true,
		autoPlay:5000,
		selectedAttraction:0.01,
		friction:0.15,
		prevNextButtons:false,
		adaptiveHeight: true
	});
	
	var $gallery2=$('#three .main-gallery').flickity();
	$('#three .right').on('click',function(){
		$gallery2.flickity('next')
	});
	var $gallery2=$('#three .main-gallery').flickity();
	$('#three .left').on('click',function(){
		$gallery2.flickity('previous')
	});

	//jScrollPane
	$('.scroll-pane').jScrollPane();
	
});

//Форма отправки 2.0
$(function() {
	$("[name=send]").click(function () {
		$(":input.error").removeClass('error');
		$(".allert").remove();

		var error;
		var btn = $(this);
		var ref = btn.closest('form').find('[required]');
		var msg = btn.closest('form').find('input, textarea');
		var send_btn = btn.closest('form').find('[name=send]');
		var send_options = btn.closest('form').find('[name=campaign_token]');

		$(ref).each(function() {
			if ($(this).val() == '') {
				var errorfield = $(this);
				$(this).addClass('error').parent('.field').append('<div class="allert"><span>Заполните это поле</span><i class="fa fa-exclamation-triangle" aria-hidden="true"></i></div>');
				error = 1;
				$(":input.error:first").focus();
				return;
			} else {
				var pattern = /^([a-z0-9_\.-])+@[a-z0-9-]+\.([a-z]{2,4}\.)?[a-z]{2,4}$/i;
				if ($(this).attr("type") == 'email') {
					if(!pattern.test($(this).val())) {
						$("[name=email]").val('');
						$(this).addClass('error error_email').parent('.field').append('<div class="allert"><span>Некоректный e-mail</span><i class="fa fa-exclamation-triangle" aria-hidden="true"></i></div>');
						error = 1;
						$(":input.error:first").focus();
					}
				}
				var patterntel = /^()[+0-9]{9,18}/i;
				if ( $(this).attr("type") == 'tel') {
					if(!patterntel.test($(this).val())) {
						$("[name=phone]").val('');
						$(this).addClass('error error_tel').parent('.field').append('<div class="allert"><span>Некоректный номер телефона</span><i class="fa fa-exclamation-triangle" aria-hidden="true"></i></div>');
						error = 1;
						$(":input.error:first").focus();
					}
				}
			}
		});
		if(!(error==1)) {
			$(send_btn).each(function() {
				$(this).attr('disabled', true);
			});
			$(send_options).each(function() {
        		var form = $(this).closest('form'), name = form.find('.name').val();
				if ($(this).val() == '') {
					$.ajax({
						type: 'POST',
						url: 'mail.php',
						data: msg,
						success: function() {
							$('form').trigger("reset");
							setTimeout(function(){  $("[name=send]").removeAttr("disabled"); }, 1000);
                            $(".fancybox-close").click();
                            yaCounter41128494.reachGoal('zayavka');
                            window.location = "http://ollwood.com.ua/success.html";
                        },
                        error: function(xhr, str) {
                        	alert('Возникла ошибка: ' + xhr.responseCode);
                        }
                    });
				} else {
					$.ajax({
						type: 'POST',
						url: 'mail.php',
						data: msg,
						success:
						$.ajax({
							type: 'POST',
							url: 'https://app.getresponse.com/add_subscriber.html',
							data: msg,
							statusCode: {0:function() {
								$('form').trigger("reset");
								setTimeout(function(){  $("[name=send]").removeAttr("disabled"); }, 1000);
								$(".fancybox-close").click();
								yaCounter41128494.reachGoal('zayavka');
                           		window.location = "http://ollwood.com.ua/success.html";
							}}
						}),
						error:  function(xhr, str) {
							alert('Возникла ошибка: ' + xhr.responseCode);
						}
					});
				}
			});
		}
		return false;
	})
});

//MENU
$(document).ready(function() {
	$('#nav').css({'visibility' : 'visible', 'opacity':'1'});

	$( "#hmt" ).click(function() {
		$('#nav').toggleClass('open');
	});

	$( "#nav li a" ).click(function() {
		$('#hmt').click();
	});
});

//parallax
$(window).scroll(function() {
	var st = $(this).scrollTop() /20;
	$(".header_parallax").css({
		"transform" : "translate3d(0px, " + st  + "%, .01px)",
		"-webkit-transform" : "translate3d(0px, " + st  + "%, .01px)",
		"-ms-transform" : "translate3d(0px, " + st  + "%, .01px)"
	});	
});
